# Pyarmor 9.0.5 (trial), 000000, 2024-11-19T06:54:17.489861
from .pyarmor_runtime import __pyarmor__